# ProGuard rules for Astro FPS
