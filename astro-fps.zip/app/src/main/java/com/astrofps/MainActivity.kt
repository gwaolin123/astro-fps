package com.astrofps

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val startBtn = findViewById<Button>(R.id.btn_start_service)
        val stopBtn = findViewById<Button>(R.id.btn_stop_service)
        val checkRootBtn = findViewById<Button>(R.id.btn_check_root)

        checkRootBtn.setOnClickListener {
            if (RootUtils.isRooted()) {
                Toast.makeText(this, "Root access confirmed", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Root required! Install Magisk.", Toast.LENGTH_LONG).show()
            }
        }

        startBtn.setOnClickListener {
            if (!RootUtils.isRooted()) {
                Toast.makeText(this, "Root access denied!", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }

            if (!Settings.canDrawOverlays(this)) {
                val intent = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
                startActivity(intent)
                return@setOnClickListener
            }

            val serviceIntent = Intent(this, AstroService::class.java)
            ContextCompat.startForegroundService(this, serviceIntent)
            Toast.makeText(this, "Astro FPS activated", Toast.LENGTH_SHORT).show()
            finish()
        }

        stopBtn.setOnClickListener {
            stopService(Intent(this, AstroService::class.java))
            Toast.makeText(this, "Astro FPS stopped", Toast.LENGTH_SHORT).show()
        }
    }
}
