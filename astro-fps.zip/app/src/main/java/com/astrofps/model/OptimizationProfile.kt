package com.astrofps.model

data class OptimizationProfile(
    val name: String,
    val cpuGovernor: String = "performance",
    val gpuGovernor: String = "performance",
    val targetFps: Int = 120,
    val qualityLevel: Int = 0,
    val disableShadows: Boolean = true,
    val disableAntiAliasing: Boolean = true,
    val reduceResolution: Boolean = false,
    val resolutionScale: Float = 1.0f,
    val thermalBypass: Boolean = true,
    val memoryLock: Boolean = true,
    val touchBoost: Boolean = true
) {
    companion object {
        val BALANCED = OptimizationProfile(
            name = "Balanced",
            cpuGovernor = "schedutil",
            gpuGovernor = "msm-adreno-tz",
            targetFps = 90,
            qualityLevel = 2,
            disableShadows = false,
            thermalBypass = false
        )

        val PERFORMANCE = OptimizationProfile(
            name = "Performance",
            cpuGovernor = "performance",
            gpuGovernor = "performance",
            targetFps = 120,
            qualityLevel = 1,
            disableShadows = true,
            thermalBypass = true
        )

        val MAXIMUM = OptimizationProfile(
            name = "Maximum",
            cpuGovernor = "performance",
            gpuGovernor = "performance",
            targetFps = 144,
            qualityLevel = 0,
            disableShadows = true,
            disableAntiAliasing = true,
            reduceResolution = true,
            resolutionScale = 0.85f,
            thermalBypass = true,
            memoryLock = true
        )
    }
}
