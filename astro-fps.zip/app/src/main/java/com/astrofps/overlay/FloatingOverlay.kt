package com.astrofps.overlay

import android.content.Context
import android.graphics.PixelFormat
import android.os.Build
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.TextView
import com.astrofps.R
import com.astrofps.engine.OptimizationEngine
import com.astrofps.utils.ShellExecutor

class FloatingOverlay(private val context: Context) {

    private val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var overlayView: View? = null
    private var isExpanded = false
    private var params: WindowManager.LayoutParams? = null
    private val handler = android.os.Handler(android.os.Looper.getMainLooper())
    private val statsRunnable = object : Runnable {
        override fun run() {
            updateStats()
            handler.postDelayed(this, 1000)
        }
    }

    fun show() {
        if (overlayView != null) return

        val inflater = LayoutInflater.from(context)
        overlayView = inflater.inflate(R.layout.overlay_main, null)

        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else
                WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 50
            y = 100
        }

        setupView(overlayView!!)
        windowManager.addView(overlayView, params)
        handler.post(statsRunnable)
    }

    private fun setupView(view: View) {
        val dragHandle = view.findViewById<View>(R.id.drag_handle)
        val contentPanel = view.findViewById<LinearLayout>(R.id.content_panel)
        val toggleBtn = view.findViewById<ImageButton>(R.id.btn_toggle)
        val closeBtn = view.findViewById<ImageButton>(R.id.btn_close)
        val boostBtn = view.findViewById<Button>(R.id.btn_boost)
        val thermalBtn = view.findViewById<Button>(R.id.btn_thermal)

        var initialX = 0
        var initialY = 0
        var touchX = 0f
        var touchY = 0f

        dragHandle.setOnTouchListener { _, event ->
            when (event.action) {
                android.view.MotionEvent.ACTION_DOWN -> {
                    initialX = params!!.x
                    initialY = params!!.y
                    touchX = event.rawX
                    touchY = event.rawY
                    true
                }
                android.view.MotionEvent.ACTION_MOVE -> {
                    params!!.x = initialX + (event.rawX - touchX).toInt()
                    params!!.y = initialY + (event.rawY - touchY).toInt()
                    windowManager.updateViewLayout(overlayView, params)
                    true
                }
                else -> false
            }
        }

        toggleBtn.setOnClickListener {
            isExpanded = !isExpanded
            contentPanel.visibility = if (isExpanded) View.VISIBLE else View.GONE
            toggleBtn.rotation = if (isExpanded) 180f else 0f
        }

        closeBtn.setOnClickListener { hide() }

        boostBtn.setOnClickListener {
            OptimizationEngine(context).applyBoostMode()
        }

        thermalBtn.setOnClickListener {
            OptimizationEngine(context).applyCoolMode()
        }
    }

    private fun updateStats() {
        val view = overlayView ?: return
        val fpsText = view.findViewById<TextView>(R.id.tv_fps)
        val tempText = view.findViewById<TextView>(R.id.tv_temp)

        fpsText.text = "FPS: ${getCurrentFps()}"
        tempText.text = "${getCpuTemp()}C"
    }

    private fun getCurrentFps(): Int {
        return try {
            val result = ShellExecutor.execute("dumpsys gfxinfo com.activision.callofduty.shooter | grep -i 'fps' | tail -1")
            result.filter { it.isDigit() }.toIntOrNull() ?: 60
        } catch (e: Exception) {
            60
        }
    }

    private fun getCpuTemp(): Float {
        return try {
            val temp = ShellExecutor.execute("cat /sys/class/thermal/thermal_zone0/temp")
            (temp.trim().toFloat() / 1000f)
        } catch (e: Exception) {
            0f
        }
    }

    fun hide() {
        handler.removeCallbacks(statsRunnable)
        overlayView?.let {
            windowManager.removeView(it)
            overlayView = null
        }
    }
}
