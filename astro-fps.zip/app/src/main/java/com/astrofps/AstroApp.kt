package com.astrofps

import android.app.Application

class AstroApp : Application() {
    override fun onCreate() {
        super.onCreate()
    }
}
