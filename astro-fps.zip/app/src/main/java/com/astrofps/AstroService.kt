package com.astrofps

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.astrofps.engine.OptimizationEngine
import com.astrofps.overlay.FloatingOverlay
import com.astrofps.utils.GameDetector
import kotlinx.coroutines.*

class AstroService : Service() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private lateinit var overlay: FloatingOverlay
    private lateinit var engine: OptimizationEngine

    override fun onCreate() {
        super.onCreate()
        overlay = FloatingOverlay(this)
        engine = OptimizationEngine(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(NOTIFICATION_ID, createNotification())

        scope.launch {
            engine.initialize()
            overlay.show()

            while (isActive) {
                if (GameDetector.isGameRunning(this@AstroService)) {
                    engine.applyGameOptimizations()
                } else {
                    engine.applyIdleOptimizations()
                }
                delay(2000)
            }
        }

        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        scope.cancel()
        overlay.hide()
        engine.cleanup()
        super.onDestroy()
    }

    private fun createNotification(): Notification {
        val channelId = "astro_fps_channel"

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "Astro FPS Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "CODM optimization service"
            }
            getSystemService(NotificationManager::class.java)?.createNotificationChannel(channel)
        }

        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, channelId)
            .setContentTitle("Astro FPS")
            .setContentText("Optimizing CODM...")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .build()
    }

    companion object {
        const val NOTIFICATION_ID = 1337
    }
}
