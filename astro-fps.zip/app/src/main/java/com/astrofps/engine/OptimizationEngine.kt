package com.astrofps.engine

import android.content.Context
import com.astrofps.utils.ShellExecutor
import kotlinx.coroutines.*

class OptimizationEngine(private val context: Context) {

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var isGaming = false

    fun initialize() {
        ShellExecutor.executeSu("setenforce 0")
        ShellExecutor.executeSu("echo 0 > /proc/sys/kernel/sched_schedstats")
    }

    fun applyGameOptimizations() {
        if (isGaming) return
        isGaming = true

        scope.launch {
            ShellExecutor.executeSu("for cpu in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do echo performance > \$cpu; done")
            ShellExecutor.executeSu("for cpu in /sys/devices/system/cpu/cpu*/cpufreq/scaling_max_freq; do cat \${cpu%/*}/cpuinfo_max_freq > \$cpu; done")
            ShellExecutor.executeSu("echo performance > /sys/class/kgsl/kgsl-3d0/devfreq/governor 2>/dev/null || echo performance > /sys/class/misc/mali0/device/clock_governor 2>/dev/null")
            ShellExecutor.executeSu("cat /sys/class/kgsl/kgsl-3d0/gpuclk > /sys/class/kgsl/kgsl-3d0/max_gpuclk 2>/dev/null")
            ShellExecutor.executeSu("stop thermald 2>/dev/null; stop thermal-engine 2>/dev/null")
            ShellExecutor.executeSu("echo 1 > /sys/class/thermal/thermal_zone0/passive 2>/dev/null")
            ShellExecutor.executeSu("echo 3 > /proc/sys/vm/drop_caches")
            ShellExecutor.executeSu("echo 1 > /proc/sys/vm/compact_memory")
            ShellExecutor.executeSu("for blk in /sys/block/*/queue/scheduler; do echo noop > \$blk 2>/dev/null || echo none > \$blk 2>/dev/null; done")
            ShellExecutor.executeSu("am kill-all 2>/dev/null")
            ShellExecutor.executeSu("cmd display mode 2 2>/dev/null")
            ShellExecutor.executeSu("echo 1 > /sys/class/power_supply/battery/touch_boost 2>/dev/null")
            ShellExecutor.executeSu("stop logd 2>/dev/null")
        }
    }

    fun applyIdleOptimizations() {
        if (!isGaming) return
        isGaming = false

        scope.launch {
            ShellExecutor.executeSu("for cpu in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do echo schedutil > \$cpu; done")
            ShellExecutor.executeSu("start thermald 2>/dev/null; start thermal-engine 2>/dev/null")
            ShellExecutor.executeSu("start logd 2>/dev/null")
        }
    }

    fun applyBoostMode() {
        scope.launch {
            ShellExecutor.executeSu("echo 1 > /sys/devices/system/cpu/cpu*/online 2>/dev/null")
            ShellExecutor.executeSu("echo 0 > /sys/devices/system/cpu/cpu*/cpufreq/scaling_min_freq")
            ShellExecutor.executeSu("echo 100 > /proc/sys/kernel/sched_rt_runtime_us")
            ShellExecutor.executeSu("echo 0 > /sys/class/kgsl/kgsl-3d0/min_pwrlevel 2>/dev/null")
            ShellExecutor.executeSu("echo 0 > /sys/class/kgsl/kgsl-3d0/max_pwrlevel 2>/dev/null")
            ShellExecutor.executeSu("settings put global window_animation_scale 0")
            ShellExecutor.executeSu("settings put global transition_animation_scale 0")
            ShellExecutor.executeSu("settings put global animator_duration_scale 0")
        }
    }

    fun applyCoolMode() {
        scope.launch {
            ShellExecutor.executeSu("start thermald 2>/dev/null")
            ShellExecutor.executeSu("echo 0 > /sys/class/thermal/thermal_zone0/passive 2>/dev/null")
            ShellExecutor.executeSu("for cpu in /sys/devices/system/cpu/cpu*/cpufreq/scaling_max_freq; do echo 1800000 > \$cpu; done")
        }
    }

    fun cleanup() {
        scope.cancel()
        applyIdleOptimizations()
        ShellExecutor.executeSu("setenforce 1")
    }
}
