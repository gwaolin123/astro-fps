package com.astrofps.utils

import android.app.ActivityManager
import android.content.Context

object GameDetector {

    private const val CODM_PACKAGE = "com.activision.callofduty.shooter"
    private const val CODM_PACKAGE_GARENA = "com.garena.game.codm"

    fun isGameRunning(context: Context): Boolean {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val runningApps = am.runningAppProcesses ?: return false

        return runningApps.any { 
            it.processName == CODM_PACKAGE || it.processName == CODM_PACKAGE_GARENA 
        }
    }
}
