#include <jni.h>
#include <android/log.h>
#include <dlfcn.h>
#include <unistd.h>

#define LOG_TAG "AstroUnity"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)

typedef void* (*il2cpp_resolve_icall_t)(const char* name);

void* il2cpp_handle = nullptr;
il2cpp_resolve_icall_t il2cpp_resolve_icall = nullptr;

extern "C" {

JNIEXPORT void JNICALL
Java_com_astrofps_engine_UnityHook_nativeHookUnity(JNIEnv* env, jobject thiz) {
    il2cpp_handle = dlopen("libil2cpp.so", RTLD_NOW);
    if (!il2cpp_handle) {
        LOGI("Failed to load libil2cpp.so");
        return;
    }

    il2cpp_resolve_icall = (il2cpp_resolve_icall_t)dlsym(il2cpp_handle, "il2cpp_resolve_icall");
    if (!il2cpp_resolve_icall) {
        LOGI("Failed to resolve il2cpp_resolve_icall");
        return;
    }

    LOGI("Unity IL2CPP hooked successfully");
}

JNIEXPORT void JNICALL
Java_com_astrofps_engine_UnityHook_nativeSetTargetFps(JNIEnv* env, jobject thiz, jint fps) {
    if (!il2cpp_resolve_icall) return;

    void* setTargetFrameRate = il2cpp_resolve_icall("UnityEngine.Application::set_targetFrameRate");
    if (setTargetFrameRate) {
        typedef void (*SetTargetFrameRate_t)(int);
        ((SetTargetFrameRate_t)setTargetFrameRate)(fps);
        LOGI("Target FPS set to %d", fps);
    }
}

JNIEXPORT void JNICALL
Java_com_astrofps_engine_UnityHook_nativeSetQualityLevel(JNIEnv* env, jobject thiz, jint level) {
    if (!il2cpp_resolve_icall) return;

    void* setQualityLevel = il2cpp_resolve_icall("UnityEngine.QualitySettings::SetQualityLevel");
    if (setQualityLevel) {
        typedef void (*SetQualityLevel_t)(int, bool);
        ((SetQualityLevel_t)setQualityLevel)(level, true);
        LOGI("Quality level set to %d", level);
    }
}

JNIEXPORT void JNICALL
Java_com_astrofps_engine_UnityHook_nativeDisableShadows(JNIEnv* env, jobject thiz) {
    if (!il2cpp_resolve_icall) return;

    void* setShadows = il2cpp_resolve_icall("UnityEngine.QualitySettings::set_shadows");
    if (setShadows) {
        typedef void (*SetShadows_t)(int);
        ((SetShadows_t)setShadows)(0);
        LOGI("Shadows disabled");
    }
}

}
