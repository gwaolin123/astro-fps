#include <jni.h>
#include <android/log.h>
#include <string>
#include <fstream>
#include <sstream>
#include <unistd.h>
#include <sys/resource.h>

#define LOG_TAG "AstroNative"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)

extern "C" {

JNIEXPORT void JNICALL
Java_com_astrofps_engine_OptimizationEngine_nativeSetPriority(JNIEnv* env, jobject thiz, jint pid, jint priority) {
    setpriority(PRIO_PROCESS, pid, priority);
    LOGI("Set priority for PID %d to %d", pid, priority);
}

JNIEXPORT void JNICALL
Java_com_astrofps_engine_OptimizationEngine_nativeLockMemory(JNIEnv* env, jobject thiz, jlong size) {
    void* addr = malloc(size);
    if (addr) {
        mlock(addr, size);
        LOGI("Locked %ld bytes in memory", size);
    }
}

JNIEXPORT jstring JNICALL
Java_com_astrofps_engine_OptimizationEngine_nativeGetCpuInfo(JNIEnv* env, jobject thiz) {
    std::ifstream file("/proc/cpuinfo");
    std::stringstream buffer;
    buffer << file.rdbuf();
    return env->NewStringUTF(buffer.str().c_str());
}

JNIEXPORT void JNICALL
Java_com_astrofps_engine_OptimizationEngine_nativeOptimizeSched(JNIEnv* env, jobject thiz) {
    system("su -c 'echo 95 > /proc/sys/kernel/sched_upmigrate'");
    system("su -c 'echo 85 > /proc/sys/kernel/sched_downmigrate'");
    system("su -c 'echo 1000000 > /proc/sys/kernel/sched_min_granularity_ns'");
    system("su -c 'echo 4000000 > /proc/sys/kernel/sched_latency_ns'");
    LOGI("Scheduler optimized for gaming");
}

}
